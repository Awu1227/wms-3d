import * as THREE from "three";

import Experience from "../Experience.js";
import Environment from "./Environment.js";
import GridHelper from "../Helper/GridHelper.js";
import Floor from "./Floor.js";
import Shelf from "./Shelf.js";
import Rack from "./Rack.js";
import Text from "./Text.js";
import Fox from "./Fox.js";
import Box from "./Box";
import Area from "./Area.js";
import Video from "./Video.js";

export default class World {
  constructor() {
    this.experience = new Experience();
    this.scene = this.experience.scene;
    this.environment = new Environment();
    this.areas = [];

    this.resources = this.experience.resources;

    // Wait for resources
    this.resources.on("ready", () => {
      this.text = new Text({ x: 0, z: 16, name: "编辑仓库" });
      // Setup
      // this.gridHelper = new GridHelper();

      this.floor = new Floor();
      // this.shelf = new Shelf({
      //     x: 0,
      //     y: 5,
      //     z:0,
      //     plane_x:6,
      //     plane_y:1,
      //     plane_z:6,
      //     holder_x: 0.5,
      //     holder_y: 5,
      //     holder_z: 0.5,
      //     rackLevel:4,
      //     name: "货架",
      //     num:2
      //   })

      // this.fox = new Fox()
      // this.video = new Video()
      // this.box = new Box();
      this.environment = new Environment();
    });

    // Test mesh
    // const testMesh = new THREE.Mesh(
    //   new THREE.BoxGeometry(1, 1, 1),
    //   new THREE.MeshStandardMaterial()
    // )
    // this.scene.add(testMesh)
  }

  update() {
    if (this.fox) this.fox.update();
    if (this.box) this.box.update();
    if (this.video) this.video.update();
    if (this.text) this.text.update();
  }
}
