import * as THREE from "three";

import Experience from "../Experience.js";

export default class Video {
  constructor() {
    this.experience = new Experience();
    this.scene = this.experience.scene;
    this.resources = this.experience.resources;
    
    this.video = document.getElementById( 'video' );

    if ( navigator.mediaDevices && navigator.mediaDevices.getUserMedia ) {

        const constraints = { video: { width: 1280, height: 720, facingMode: 'user' } };

        navigator.mediaDevices.getUserMedia( constraints ).then( function ( stream ) {

            // apply the stream to the video element used in the texture

            this.video.srcObject = stream;
            this.video.play();

        } ).catch( function ( error ) {

            console.error( 'Unable to access the camera/webcam.', error );

        } );

    } else {

        console.error( 'MediaDevices interface not available.' );

    }

    // Setup
    this.setGeometry();
    this.setTextures();
    this.setMaterial();
    this.setMesh();
  }

  setGeometry() {
    this.geometry = new THREE.PlaneGeometry( 2, 2 );
  }

  setTextures() {
    this.texture = new THREE.VideoTexture( this.video );

    this.texture.colorSpace = THREE.SRGBColorSpace;
  }

  setMaterial() {
    this.material = new THREE.MeshBasicMaterial( { map: this.texture } );
  }

  setMesh() {
    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.mesh.position.y = 1;
    this.mesh.castShadow = true;
    this.scene.add(this.mesh);
  }
  update() {
    this.mesh.rotation.x += 0.01;
    this.mesh.rotation.y += 0.01;
  }
}
