import * as THREE from "three";
import Rack from "./Rack.js";
import * as _ from "lodash";
import Experience from "../Experience.js";

export default class Shelf {
  constructor(config) {
    const { rackLevel } = config
    this.rackList = []
    for (let index = 0; index < rackLevel; index++) {
        const rackConfig = _.cloneDeep(config)
        rackConfig.y += config.y * index 
        const rack = new Rack(rackConfig)
        this.rackList.push(rack)
    }
    
    this.experience = new Experience();
    this.scene = this.experience.scene;
    this.resources = this.experience.resources;

  }


  update() {
    this.mesh.rotation.x += 0.01;
    this.mesh.rotation.y += 0.01;
  }
  destroy() {
    this.rackList.forEach(rack => rack.destroy())
  }
}
