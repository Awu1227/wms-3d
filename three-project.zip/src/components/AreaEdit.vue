<template>
  <el-dialog v-model="props.visible" title="库区编辑" width="800">
    <el-table :data="props.areaData.shelfList" border>
      <el-table-column property="name" label="货架名称" width="200" />
      <el-table-column label="操作">
          <template #default="scope">
            <el-button
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
            >
              编辑
            </el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.$index, scope.row)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
    </el-table>
  </el-dialog>
</template>
    
<script setup lang='ts'>
// define props and emits
const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  areaData: {
    type: Object,
    default: {}
  }
})
const handleEdit = (index, row) => {
  console.log(index, row)

}
const handleDelete = (index, row) => {
//   tableData.value = tableData.value.filter(item => item.id !== row.id)
}

</script>
    
<style>
    
</style>